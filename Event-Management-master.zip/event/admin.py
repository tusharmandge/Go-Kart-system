from django.contrib import admin

from .models import EventRecord, DataList

admin.site.register(EventRecord)
admin.site.register(DataList)
